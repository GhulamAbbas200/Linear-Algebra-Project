"""
==============================================================================
APPLICATION OF LU DECOMPOSITION IN DATA SCIENCE
Multiple Linear Regression via the Normal Equations
==============================================================================

PROBLEM STATEMENT
------------------
A real-estate analytics team wants to predict a HOUSE PRICE (in lakh PKR)
from three measurable features of a property:

    x1 = Area of the house       (in hundreds of sq. ft.)
    x2 = Number of bedrooms
    x3 = Age of the house        (in years)

They propose the linear model:

    price = b0 + b1*x1 + b2*x2 + b3*x3

Given a dataset of n = 6 houses (features + observed price), the "best fit"
coefficients b0, b1, b2, b3 that minimise the sum of squared errors are the
solution of the NORMAL EQUATIONS of least squares:

        (X^T X) * b = X^T y                       ... (*)

where X is the (n x 4) design matrix (a column of 1's for the intercept,
followed by the 3 feature columns) and y is the (n x 1) vector of observed
prices.

Equation (*) is a SQUARE, symmetric 4x4 SYSTEM OF LINEAR EQUATIONS
    A b = c        where   A = X^T X (4x4),   c = X^T y (4x1)

This is exactly the type of system solved by hand in the reference example
(a 3x3 system Ax = B solved through LU decomposition). Here we solve the
LARGER, more realistic 4x4 system that arises from real data, using the
SAME method: LU Decomposition (Doolittle's method with partial pivoting).

WHY LU DECOMPOSITION (and not just np.linalg.solve)?
------------------------------------------------------
In real Data-Science / Big-Data pipelines the matrix A = X^T X is reused
many times (e.g. cross-validation, re-weighted least squares, ridge
regression with different right-hand sides). Decomposing A = L U ONCE
(cost ~ n^3/3) lets us re-solve for many different right-hand-side vectors
b very cheaply using only forward/backward substitution (cost ~ n^2) instead
of repeating full Gaussian elimination every time. This is the standard
reason LU decomposition is preferred in numerical/data-science software
(MATLAB's backslash operator and SciPy's linalg.lu_factor both work this way).

------------------------------------------------------------------------------
The code below is fully GENERIC: the function lu_decomposition() and the
solver solve_lu() work for ANY square matrix (2x2, 3x3, 4x4, ... n x n),
not just the specific example. Three demonstrations are included:
    DEMO 1 : 2x2 system (sanity check)
    DEMO 2 : 3x3 system  -> identical to the hand-solved example in the
             uploaded notebook pages (used to VERIFY our code is correct)
    DEMO 3 : 4x4 system  -> the real Data-Science application (house-price
             normal equations)
==============================================================================
"""

import numpy as np

np.set_printoptions(precision=4, suppress=True)


# ==============================================================================
# STEP 1: GENERIC LU DECOMPOSITION  (Doolittle's method with partial pivoting)
#          PA = LU
# ==============================================================================
def lu_decomposition(A, use_pivoting=False):
    """
    Decomposes a square matrix A (n x n) such that:
            P @ A = L @ U
    P : permutation matrix (identity if use_pivoting=False)
    L : lower-triangular matrix with unit diagonal
    U : upper-triangular matrix

    use_pivoting=False (default) -> plain Doolittle LU, NO row swaps.
        This reproduces a hand-worked / textbook solution exactly
        (same multipliers, same L and U you'd get solving by hand).
    use_pivoting=True  -> partial pivoting for numerical stability.
        Needed only if a zero pivot is encountered, or for
        ill-conditioned matrices.

    Works for ANY n x n matrix (n = 2, 3, 4, ...).
    """
    A = np.array(A, dtype=float)
    n = A.shape[0]

    U = A.copy()
    L = np.eye(n)
    P = np.eye(n)

    for k in range(n - 1):
        if use_pivoting:
            # ---- Partial pivoting: pick the largest pivot in column k ----
            pivot_row = np.argmax(np.abs(U[k:, k])) + k
            if pivot_row != k:
                U[[k, pivot_row], :] = U[[pivot_row, k], :]
                P[[k, pivot_row], :] = P[[pivot_row, k], :]
                if k > 0:
                    L[[k, pivot_row], :k] = L[[pivot_row, k], :k]

        if abs(U[k, k]) < 1e-12:
            raise ValueError(
                "Zero pivot encountered — plain LU (no pivoting) cannot "
                "continue here. Re-run with use_pivoting=True."
            )

        # ---- Elimination step: create zeros below the pivot ----
        for i in range(k + 1, n):
            multiplier = U[i, k] / U[k, k]
            L[i, k] = multiplier
            U[i, k:] = U[i, k:] - multiplier * U[k, k:]

    return P, L, U


# ==============================================================================
# STEP 2: FORWARD SUBSTITUTION   ->   solves  L y = Pb   for y
# ==============================================================================
def forward_substitution(L, b):
    n = len(b)
    y = np.zeros(n)
    for i in range(n):
        y[i] = b[i] - np.dot(L[i, :i], y[:i])
        # L has unit diagonal (L[i, i] == 1), so no division needed
    return y


# ==============================================================================
# STEP 3: BACKWARD SUBSTITUTION  ->   solves  U x = y        for x
# ==============================================================================
def backward_substitution(U, y):
    n = len(y)
    x = np.zeros(n)
    for i in range(n - 1, -1, -1):
        x[i] = (y[i] - np.dot(U[i, i + 1:], x[i + 1:])) / U[i, i]
    return x


# ==============================================================================
# STEP 4: FULL SOLVER  ->  solves A x = b  for ANY n x n system using LU
# ==============================================================================
def solve_lu(A, b, verbose=True, label="", use_pivoting=False):
    A = np.array(A, dtype=float)
    b = np.array(b, dtype=float)

    P, L, U = lu_decomposition(A, use_pivoting=use_pivoting)
    Pb = P @ b
    y = forward_substitution(L, Pb)
    x = backward_substitution(U, y)

    if verbose:
        print(f"\n{'='*70}\n{label}\n{'='*70}")
        print(f"A =\n{A}")
        print(f"\nb =\n{b}")
        print(f"\nStep 1: PA = LU")
        print(f"P (permutation matrix) =\n{P}")
        print(f"L (lower triangular) =\n{L}")
        print(f"U (upper triangular) =\n{U}")
        print(f"\nCheck  L @ U == P @ A ?  -> {np.allclose(L @ U, P @ A)}")
        print(f"\nStep 2: Forward substitution  L y = Pb")
        print(f"Pb = {Pb}")
        print(f"y  = {y}")
        print(f"\nStep 3: Backward substitution  U x = y")
        print(f"x  = {x}")
        print(f"\nVerification  A @ x =\n{A @ x}   (should equal b = {b})")
        print(f"\nCross-check with numpy.linalg.solve -> {np.linalg.solve(A, b)}")
    return x


# ==============================================================================
# DEMO 1 : 2x2 SYSTEM  (sanity check that the code generalises to any size)
# ==============================================================================
A2 = [[4, 3],
      [6, 3]]
b2 = [10, 12]
x2 = solve_lu(A2, b2, use_pivoting=False, label="DEMO 1: Generic 2x2 system  Ax = b")


# ==============================================================================
# DEMO 2 : 3x3 SYSTEM -- reproduces the hand-solved example from the notebook
#          2x + 3y - 4z = 3
#           x + 2y - 6z = 1
#          4x +  y +  z = 2
# ==============================================================================
A3 = [[2, 3, -4],
      [1, 2, -6],
      [4, 1, 1]]
b3 = [3, 1, 7]  # matches the notebook's B = [3, 1, 7] exactly
x3 = solve_lu(A3, b3, use_pivoting=False,
              label="DEMO 2: 3x3 system (no pivoting — matches hand-worked notebook exactly)")


# ==============================================================================
# DEMO 3 : 4x4 SYSTEM -- THE ACTUAL DATA-SCIENCE APPLICATION
#          Multiple Linear Regression Normal Equations  (X^T X) b = X^T y
# ==============================================================================
print(f"\n{'#'*70}")
print("DATA-SCIENCE APPLICATION: House-Price Multiple Linear Regression")
print(f"{'#'*70}")

# Raw dataset: [Area(hundred sqft), Bedrooms, Age(years)] -> Price (lakh PKR)
houses = np.array([
    # Area, Bedrooms, Age
    [10, 2,  5],
    [15, 3,  8],
    [12, 3, 12],
    [20, 4,  3],
    [8,  2, 20],
    [18, 4,  6],
], dtype=float)

price = np.array([55, 78, 62, 105, 40, 96], dtype=float)   # observed prices

n_samples = houses.shape[0]
X = np.hstack([np.ones((n_samples, 1)), houses])   # add intercept column of 1s
y = price

print("\nDesign matrix X (column of 1's + features):")
print(X)
print("\nObserved price vector y:")
print(y)

# Build the normal equations   A b = c
A_reg = X.T @ X
c_reg = X.T @ y

b_reg = solve_lu(A_reg, c_reg,
                  label="DEMO 3: 4x4 Normal Equations (X^T X) b = X^T y")

print("\n" + "-"*70)
print("FINAL REGRESSION MODEL")
print("-"*70)
print(f"price = {b_reg[0]:.4f} "
      f"+ ({b_reg[1]:.4f})*Area "
      f"+ ({b_reg[2]:.4f})*Bedrooms "
      f"+ ({b_reg[3]:.4f})*Age")

# Predict price for a new house: 14 (hundred sqft), 3 bedrooms, 10 years old
new_house = np.array([1, 14, 3, 10])
predicted_price = new_house @ b_reg
print(f"\nPredicted price for a house (Area=1400 sqft, 3 bedrooms, "
      f"Age=10 yrs): {predicted_price:.2f} lakh PKR")

# Cross-check against scikit-learn-style closed form (numpy lstsq) for validation
b_check = np.linalg.solve(A_reg, c_reg)
print(f"\nValidation against numpy.linalg.solve -> {b_check}")
print(f"Match with our LU solver              -> {b_reg}")
print(f"Match: {np.allclose(b_reg, b_check)}")
