"""
==============================================================================
STREAMLIT APP:  LU Decomposition Solver
Application: Data Science -> Multiple Linear Regression via Normal Equations
==============================================================================
Run locally with:
    pip install streamlit numpy pandas
    streamlit run app.py
==============================================================================
"""

import numpy as np
import pandas as pd
import streamlit as st

st.set_page_config(page_title="LU Decomposition Solver", layout="wide")


# ==============================================================================
# CORE LU DECOMPOSITION ENGINE (generic, works for any n x n matrix)
# ==============================================================================
def lu_decomposition(A, use_pivoting=False):
    """
    Doolittle's method.
    use_pivoting=False -> plain LU, no row swaps (matches textbook / hand
                          -worked examples exactly: A = LU, P = Identity).
    use_pivoting=True  -> partial pivoting for numerical stability: PA = LU.
    """
    A = np.array(A, dtype=float)
    n = A.shape[0]
    U = A.copy()
    L = np.eye(n)
    P = np.eye(n)

    for k in range(n - 1):
        if use_pivoting:
            pivot_row = np.argmax(np.abs(U[k:, k])) + k
            if pivot_row != k:
                U[[k, pivot_row], :] = U[[pivot_row, k], :]
                P[[k, pivot_row], :] = P[[pivot_row, k], :]
                if k > 0:
                    L[[k, pivot_row], :k] = L[[pivot_row, k], :k]

        if abs(U[k, k]) < 1e-12:
            raise ValueError(
                "Zero pivot encountered at this step — plain LU (no "
                "pivoting) cannot continue. Turn pivoting ON to solve this "
                "matrix, or reorder the rows yourself."
            )

        for i in range(k + 1, n):
            multiplier = U[i, k] / U[k, k]
            L[i, k] = multiplier
            U[i, k:] = U[i, k:] - multiplier * U[k, k:]

    return P, L, U


def forward_substitution(L, b):
    n = len(b)
    y = np.zeros(n)
    for i in range(n):
        y[i] = b[i] - np.dot(L[i, :i], y[:i])
    return y


def backward_substitution(U, y):
    n = len(y)
    x = np.zeros(n)
    for i in range(n - 1, -1, -1):
        x[i] = (y[i] - np.dot(U[i, i + 1:], x[i + 1:])) / U[i, i]
    return x


def solve_lu(A, b, use_pivoting=False):
    """Returns a dict with every intermediate step so the UI can display them."""
    A = np.array(A, dtype=float)
    b = np.array(b, dtype=float)
    P, L, U = lu_decomposition(A, use_pivoting=use_pivoting)
    Pb = P @ b
    y = forward_substitution(L, Pb)
    x = backward_substitution(U, y)
    return {
        "A": A, "b": b, "P": P, "L": L, "U": U,
        "Pb": Pb, "y": y, "x": x,
        "check_LU": np.allclose(L @ U, P @ A),
        "check_Ax": A @ x,
        "numpy_solution": np.linalg.solve(A, b),
    }


def mat_to_df(M, row_prefix="R", col_prefix="C"):
    n, m = M.shape
    return pd.DataFrame(
        M,
        index=[f"{row_prefix}{i+1}" for i in range(n)],
        columns=[f"{col_prefix}{j+1}" for j in range(m)],
    )


def show_steps(result, x_labels=None):
    """Renders all LU decomposition steps in the UI."""
    n = result["A"].shape[0]
    if x_labels is None:
        x_labels = [f"x{i+1}" for i in range(n)]

    is_plain = np.allclose(result["P"], np.eye(result["P"].shape[0]))
    st.subheader("Step 1 — Decompose: A = LU" if is_plain else "Step 1 — Decompose: PA = LU")
    c1, c2, c3 = st.columns(3)
    with c1:
        st.markdown("**P** (identity — no row swaps)" if is_plain else "**P** (row-swap / permutation matrix)")
        st.dataframe(mat_to_df(result["P"]))
    with c2:
        st.markdown("**L** (lower triangular, unit diagonal)")
        st.dataframe(mat_to_df(result["L"]).style.format("{:.4f}"))
    with c3:
        st.markdown("**U** (upper triangular)")
        st.dataframe(mat_to_df(result["U"]).style.format("{:.4f}"))

    if result["check_LU"]:
        st.success("Verified: L · U = P · A ✔")
    else:
        st.error("L · U ≠ P · A — something went wrong.")

    st.subheader("Step 2 — Forward substitution: Ly = Pb")
    st.write("Pb =", np.round(result["Pb"], 4))
    st.write("y  =", np.round(result["y"], 4))

    st.subheader("Step 3 — Backward substitution: Ux = y")
    x_df = pd.DataFrame({"Variable": x_labels, "Value": np.round(result["x"], 4)})
    st.dataframe(x_df, hide_index=True)

    st.subheader("Verification")
    v1, v2 = st.columns(2)
    with v1:
        st.write("A · x (should equal b):")
        st.write(np.round(result["check_Ax"], 4))
    with v2:
        st.write("b (original right-hand side):")
        st.write(result["b"])

    match = np.allclose(result["x"], result["numpy_solution"])
    st.write("Cross-check against `numpy.linalg.solve`:", np.round(result["numpy_solution"], 4))
    st.success("Matches NumPy's solver ✔") if match else st.error("Mismatch with NumPy solver!")


# ==============================================================================
# APP LAYOUT
# ==============================================================================
st.title("🔢 LU Decomposition Solver")
st.caption(
    "Solve any 2×2, 3×3, or 4×4 system Ax = b step-by-step using LU "
    "decomposition (Doolittle's method with partial pivoting), or explore the "
    "Data Science application: fitting a multiple linear regression model via "
    "the normal equations (XᵀX)b = Xᵀy."
)

tab1, tab2 = st.tabs(
    ["🧮 Manual System Solver (2×2 / 3×3 / 4×4)",
     "🏠 Data Science App: House-Price Regression"]
)

# ------------------------------------------------------------------------------
# TAB 1: Manual solver with user-entered matrices
# ------------------------------------------------------------------------------
with tab1:
    st.markdown(
        "Enter your own coefficient matrix **A** and right-hand-side vector "
        "**b** for the system **Ax = b**. Pick the size, edit the cells "
        "directly, then click Solve."
    )

    size = st.radio("Matrix size", [2, 3, 4], horizontal=True, index=1)

    default_A = {
        2: [[4, 3], [6, 3]],
        3: [[2, 3, -4], [1, 2, -6], [4, 1, 1]],
        4: [[2, 1, 1, 0], [4, 3, 3, 1], [8, 7, 9, 5], [6, 7, 9, 8]],
    }[size]
    default_b = {2: [10, 12], 3: [3, 1, 7], 4: [4, 11, 31, 40]}[size]

    col_a, col_b = st.columns([2, 1])
    with col_a:
        st.markdown("**Matrix A**")
        A_df = pd.DataFrame(
            default_A,
            columns=[f"C{i+1}" for i in range(size)],
            index=[f"R{i+1}" for i in range(size)],
        )
        A_edited = st.data_editor(A_df, key=f"A_editor_{size}")

    with col_b:
        st.markdown("**Vector b**")
        b_df = pd.DataFrame({"b": default_b}, index=[f"R{i+1}" for i in range(size)])
        b_edited = st.data_editor(b_df, key=f"b_editor_{size}")

    pivot_toggle = st.checkbox(
        "Use partial pivoting (row swaps for numerical stability)",
        value=False,
        key="pivot_tab1",
        help="Leave OFF to reproduce a hand-worked / textbook solution "
             "exactly (plain Doolittle LU, no row swaps). Turn ON only if "
             "your matrix needs pivoting to avoid a zero pivot."
    )

    if st.button("🚀 Solve using LU Decomposition", type="primary"):
        A_input = A_edited.to_numpy(dtype=float)
        b_input = b_edited["b"].to_numpy(dtype=float)
        try:
            result = solve_lu(A_input, b_input, use_pivoting=pivot_toggle)
            show_steps(result)
        except ValueError as e:
            st.error(str(e))
        except np.linalg.LinAlgError:
            st.error("This matrix is singular — the system has no unique solution.")

# ------------------------------------------------------------------------------
# TAB 2: Data Science application — house price regression
# ------------------------------------------------------------------------------
with tab2:
    st.markdown(
        """
### Problem
Predict **house price** (lakh PKR) from three features:
**Area** (hundred sq. ft.), **Bedrooms**, and **Age** (years), using the model:

`price = b0 + b1·Area + b2·Bedrooms + b3·Age`

The least-squares best-fit coefficients solve the **normal equations**:

`(XᵀX) b = Xᵀy`

— a 4×4 system, solved below with the same LU decomposition engine.
Edit the dataset table to use your own data.
        """
    )

    default_data = pd.DataFrame({
        "Area": [10, 15, 12, 20, 8, 18],
        "Bedrooms": [2, 3, 3, 4, 2, 4],
        "Age": [5, 8, 12, 3, 20, 6],
        "Price": [55, 78, 62, 105, 40, 96],
    })

    data_edited = st.data_editor(
        default_data, num_rows="dynamic", key="house_data_editor"
    )

    pivot_toggle_reg = st.checkbox(
        "Use partial pivoting (row swaps for numerical stability)",
        value=False,
        key="pivot_tab2",
        help="XᵀX is symmetric positive-definite for this data, so plain "
             "LU (no pivoting) works fine and matches manual working."
    )

    if st.button("📈 Fit Regression Model via LU Decomposition", type="primary"):
        df = data_edited.dropna()
        if len(df) < 4:
            st.error("Need at least 4 data rows to solve a 4×4 system uniquely.")
        else:
            X = np.hstack([np.ones((len(df), 1)), df[["Area", "Bedrooms", "Age"]].to_numpy(dtype=float)])
            y = df["Price"].to_numpy(dtype=float)

            A_reg = X.T @ X
            c_reg = X.T @ y

            st.markdown("**Design matrix X** (1's column + features):")
            st.dataframe(pd.DataFrame(X, columns=["Intercept", "Area", "Bedrooms", "Age"]))

            st.markdown("**Normal equations built:** A = XᵀX, c = Xᵀy")
            result = solve_lu(A_reg, c_reg, use_pivoting=pivot_toggle_reg)
            show_steps(result, x_labels=["b0 (Intercept)", "b1 (Area)", "b2 (Bedrooms)", "b3 (Age)"])

            b0, b1, b2, b3 = result["x"]
            st.markdown("### Final Model")
            st.latex(
                f"price = {b0:.3f} + ({b1:.3f})\\cdot Area + ({b2:.3f})\\cdot Bedrooms + ({b3:.3f})\\cdot Age"
            )

            st.markdown("### Try a Prediction")
            p1, p2, p3 = st.columns(3)
            with p1:
                area_in = st.number_input("Area (hundred sq ft)", value=14.0)
            with p2:
                bed_in = st.number_input("Bedrooms", value=3.0)
            with p3:
                age_in = st.number_input("Age (years)", value=10.0)

            predicted = b0 + b1 * area_in + b2 * bed_in + b3 * age_in
            st.success(f"Predicted price: **{predicted:.2f} lakh PKR**")

st.divider()
st.caption(
    "Method: Doolittle's LU Decomposition with partial pivoting (PA = LU), "
    "followed by forward substitution (Ly = Pb) and backward substitution (Ux = y). "
    "Verified against numpy.linalg.solve for correctness."
)
